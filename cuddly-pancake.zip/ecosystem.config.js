module.exports = {
  apps: [
    {
      name: 'Simple REST API',
      script: 'dist/src/main.js',
      watch: '.',
    },
  ],
};
