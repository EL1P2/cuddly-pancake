import { Employee } from '../entities/employee.entity';

export type UpdateEmployeeDto = Partial<Employee>;
