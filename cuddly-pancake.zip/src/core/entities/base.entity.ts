export class BaseModel {
  id: number;
}
